// auto-generated

@import Foundation;
unsigned long IOSurfaceClientCreateMachPortWithOptions()
{
	return 0;
}
unsigned long IOSurfaceClientGetBytesPerRowOfTileDataOfPlane()
{
	return 0;
}
unsigned long IOSurfaceClientGetBytesPerTileDataOfPlane()
{
	return 0;
}
unsigned long IOSurfaceClientGetCompressionFootprintOfPlane()
{
	return 0;
}
unsigned long IOSurfaceClientGetParentID()
{
	return 0;
}
unsigned long IOSurfaceClientGetTraceID()
{
	return 0;
}
unsigned long IOSurfaceClientSetImageOriginAndExtents()
{
	return 0;
}
unsigned long IOSurfaceCreateMachPortWithOptions()
{
	return 0;
}
unsigned long IOSurfaceGetBytesPerRowOfTileDataOfPlane()
{
	return 0;
}
unsigned long IOSurfaceGetBytesPerTileDataOfPlane()
{
	return 0;
}
unsigned long IOSurfaceGetCompressionFootprintOfPlane()
{
	return 0;
}
unsigned long IOSurfaceGetTraceID()
{
	return 0;
}
unsigned long IOSurfaceNotifierInvalidate()
{
	return 0;
}
unsigned long IOSurfaceSetImageOriginAndExtents()
{
	return 0;
}
NSString* kIOSurfaceClientAddressOffset=@"kIOSurfaceClientAddressOffset";
NSString* kIOSurfaceClientAddressRanges=@"kIOSurfaceClientAddressRanges";
NSString* kIOSurfaceClientDirection=@"kIOSurfaceClientDirection";
NSString* kIOSurfaceHDRImageStatisticsInfoFiltered=@"kIOSurfaceHDRImageStatisticsInfoFiltered";
NSString* kIOSurfaceHDRImageStatisticsInfoRaw=@"kIOSurfaceHDRImageStatisticsInfoRaw";
NSString* kIOSurfaceHDRImageStatisticsInfoTransferFunction=@"kIOSurfaceHDRImageStatisticsInfoTransferFunction";
NSString* kIOSurfaceHDRImageStatisticsInfo_Average=@"kIOSurfaceHDRImageStatisticsInfo_Average";
NSString* kIOSurfaceHDRImageStatisticsInfo_Maximum=@"kIOSurfaceHDRImageStatisticsInfo_Maximum";
NSString* kIOSurfaceHDRImageStatisticsInfo_Minimum=@"kIOSurfaceHDRImageStatisticsInfo_Minimum";
NSString* kIOSurfaceIsPrivate=@"kIOSurfaceIsPrivate";
NSString* kIOSurfacePlaneBytesPerRowOfTileData=@"kIOSurfacePlaneBytesPerRowOfTileData";
NSString* kIOSurfacePlaneBytesPerTileData=@"kIOSurfacePlaneBytesPerTileData";
NSString* kIOSurfacePlaneCompressionFootprint=@"kIOSurfacePlaneCompressionFootprint";
